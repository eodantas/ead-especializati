export const URL_API = 'http://localhost:8180'
export const TOKEN_NAME = 'auth_ead'

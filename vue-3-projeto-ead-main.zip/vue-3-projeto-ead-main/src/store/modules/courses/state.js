const state = {
    myCourses: [],

    courseSelected: {
        id: '',
        name: '',
        modules: []
    },

    lessonPlayer: {
        id: '',
        name: '',
        description: '',
        video: '',
        views: [],
    }
}

export default state
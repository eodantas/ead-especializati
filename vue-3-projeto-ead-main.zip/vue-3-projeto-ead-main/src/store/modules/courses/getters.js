const getters = {

}

export default getters
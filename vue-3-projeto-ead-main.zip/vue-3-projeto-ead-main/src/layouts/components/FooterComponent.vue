<template>
    <footer>
        <span class="copyright fontSmall">
            Todos os Direitos reservados - <b>Especializati</b>
        </span>
    </footer>
</template>

<script>
export default {
    name: 'footer-component'
}
</script>